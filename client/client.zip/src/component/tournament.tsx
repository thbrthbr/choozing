const Tournament = () => {
  return <></>;
};

export default Tournament;
