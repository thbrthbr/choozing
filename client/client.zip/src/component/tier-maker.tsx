const Tiermaker = () => {
  return <></>;
};

export default Tiermaker;
