import styled, { keyframes, css } from 'styled-components';
import { useRef, useState, useEffect, useInsertionEffect } from 'react';

const $MainContainer = styled.div`
  display: flex;
  flex-direction: column;
  /* justify-content: center; */
  align-items: center;
  background-color: #dfccfb;
  min-height: 100vh;
  height: 100%;
`;

const Picker = () => {
  const [start, setStart] = useState<any>('');
  const [end, setEnd] = useState<any>('');
  const [show, setShow] = useState(false);
  const [theNumber, setTheNumber] = useState(10000);
  const [test, setTest] = useState(false);

  let prevent = true;
  const pick = () => {
    if (prevent) {
      prevent = false;
      setTimeout(() => {
        prevent = true;
      }, 4000);
      if (isNaN(+start) || isNaN(+end)) {
        setStart('');
        setEnd('');
        alert('숫자만 입력할 수 있습니다');
        return;
      }
      let min = Math.min(start, end);
      let max = Math.max(start, end);
      if (max > 4000) {
        alert('4000 이하의 숫자까지 가능합니다');
        return;
      }
      if (min < 0) {
        alert('0 이상의 숫자부터 가능합니다');
        return;
      }
      let numberArr: number[] = [];
      for (let i = min; i <= max; i++) {
        numberArr.push(i);
      }

      let speed = setInterval(() => {
        const num = Math.floor(Math.random() * max) + min;
        setTheNumber(() => num);
      }, 20);

      setTimeout(() => {
        clearInterval(speed);
        setTest(!test);
      }, 3030);
      setShow(true);
    }
  };

  useEffect(() => {
    if (theNumber !== 10000) {
      alert(theNumber + '번이 뽑혔습니다!');
    }
  }, [test]);
  return (
    <$MainContainer>
      <div style={{ fontSize: '140px' }}>
        {theNumber === 10000 ? 0 : theNumber}
      </div>
      <h2>시작숫자를 넣어주세요</h2>
      <input
        type="text"
        value={start}
        onChange={(e) => setStart(e.target.value)}
      ></input>
      <h2>끝숫자를 넣어주세요</h2>
      <input
        type="text"
        value={end}
        onChange={(e) => setEnd(e.target.value)}
      ></input>
      <button onClick={pick}>GO</button>
    </$MainContainer>
  );
};

export default Picker;
