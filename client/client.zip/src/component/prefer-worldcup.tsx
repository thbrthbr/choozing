const PreferWorldcup = () => {
  return <></>;
};

export default PreferWorldcup;
