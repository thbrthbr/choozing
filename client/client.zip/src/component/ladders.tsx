const Ladders = () => {
  return <></>;
};

export default Ladders;
